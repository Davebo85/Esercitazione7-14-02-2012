package ppl.test.betthenumber;

public interface MesssageReceiver {

	void receiveMessage(String msg);
}
